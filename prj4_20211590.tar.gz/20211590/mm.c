/*
 * mm-naive.c - The fastest, least memory-efficient malloc package.
 * 
 * In this naive approach, a block is allocated by simply incrementing
 * the brk pointer.  A block is pure payload. There are no headers or
 * footers.  Blocks are never coalesced or reused. Realloc is
 * implemented directly using mm_malloc and mm_free.
 *
 * NOTE TO STUDENTS: Replace this header comment with your own header
 * comment that gives a high level description of your solution.
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>

#include "mm.h"
#include "memlib.h"

/*********************************************************
 * NOTE TO STUDENTS: Before you do anything else, please
 * provide your information in the following struct.
 ********************************************************/
team_t team = {
        /* Your student ID */
        "20211590",
        /* Your full name*/
        "Eunkyo Jeong",
        /* Your email address */
        "eunkyo789@sogang.ac.kr",
};


/* Basic constants and macros */
#define WSIZE       4
#define DSIZE       8
#define CHUNKSIZE  (1<<12)  
#define ALIGNMENT 8        
#define PLACE_THRESHOLD ALIGNMENT << 3

#define MAX(x, y) ((x) > (y)? (x) : (y))
#define MIN(x, y) ((x) < (y)? (x) : (y))

#define PACK(size, alloc)  ((size) | (alloc))

#define GET(p)       (*(unsigned int *)(p))
#define PUT(p, val)  (*(unsigned int *)(p) = (val))


#define GET_SIZE(p)  (GET(p) & ~0x7)
#define GET_ALLOC(p) (GET(p) & 0x1)


#define HDRP(bp)       ((char *)(bp) - WSIZE)
#define FTRP(bp)       ((char *)(bp) + GET_SIZE(HDRP(bp)) - DSIZE)


#define NEXT_BLKP(bp)  ((char *)(bp) + GET_SIZE(((char *)(bp) - WSIZE)))
#define PREV_BLKP(bp)  ((char *)(bp) - GET_SIZE(((char *)(bp) - DSIZE)))


#define ALIGN(size) (((size) + (ALIGNMENT-1)) & ~0x7)

#define NEXT_BLK(ptr) (*(char **)(ptr))
#define PREV_BLK(ptr) (*(char **)(ptr + WSIZE))
#define BLOCK_SIZE(ptr) (GET_SIZE(HDRP(ptr)))
#define SET(p, ptr) (*(uintptr_t *)(p) = (uintptr_t)(ptr))

#define SET_HDR(bp, size, alloc) PUT(HDRP(bp), PACK(size, alloc))
#define SET_FTR(bp, size, alloc) PUT(FTRP(bp), PACK(size, alloc))
/* $end mallocmacros */

/* Global variables */
static void *heap_listp = 0;

/* function prototypes */
static void *extend_heap(size_t words);
static char *extend_heap2(char *bp, size_t asize, int *left_ptr);
int mm_init(void);
void *mm_malloc(size_t size);
void mm_free(void *bp);
void *extend_and_coalesce(void *ptr, size_t asize);
void *mm_realloc(void *ptr, size_t size);
static void insert(char *ptr, size_t size);
static void delete(char *ptr);
static void *coalesce(void *bp);



static void *extend_heap(size_t words) {
    void *bp = mem_sbrk(ALIGN(words));
    if(bp == (void *) -1) return NULL;
    
    SET_HDR(bp, ALIGN(words), 0);
    SET_FTR(bp, ALIGN(words), 0);

    SET_HDR(NEXT_BLKP(bp), 0, 1);               
    insert(bp, ALIGN(words));

    return coalesce(bp);
}


static char *extend_heap2(char *bp, size_t asize, int *left_ptr) {
    // If bp is NULL, extend the heap by the larger of asize or CHUNKSIZE
    if (bp == NULL) {
        size_t extend_size = MAX(asize, CHUNKSIZE);
        bp = extend_heap(extend_size);
        return bp;
    }

    // If left_ptr is valid and its value is negative, extend the heap
    if (left_ptr && *left_ptr < 0) {
        size_t extend_size = MAX(CHUNKSIZE, -(*left_ptr));
        char *new_bp = extend_heap(extend_size);

        // If extending the heap fails, return NULL
        if (new_bp == NULL) {
            return NULL;
        }

        // Update left_ptr with the extended size
        *left_ptr += extend_size;
    }

    return bp;
}


int mm_init(void) {

    heap_listp = NULL;
    char *heap_s = mem_sbrk(WSIZE << 2);
    if(heap_s == (void *) -1) return (void *) -1;

    if(heap_s != (void *) -1) {
        PUT(heap_s, 0);                             // Alignment
        PUT(WSIZE + heap_s, PACK(DSIZE, 1));        // Prologue header
        PUT((WSIZE << 1) + heap_s, PACK(DSIZE, 1)); // Prologue footer
        PUT(3 * WSIZE + heap_s, PACK(0, 1));        // Epilogue header
        if(extend_heap(1 << 6) != 0) return 0;
    }
    return -1;
}



void *mm_malloc(size_t size) {
    if (size == 0) return NULL;

    size_t asize = MAX(ALIGN(size + DSIZE), DSIZE << 1);
    char *bp = heap_listp;

    while (bp && BLOCK_SIZE(bp) < asize) bp = NEXT_BLK(bp);
    bp = extend_heap2(bp, asize, NULL);

    if (bp == NULL) return NULL;

    delete(bp);

    size_t csize = BLOCK_SIZE(bp);
    size_t free_ptr = csize - asize;
    size_t block_size_min = DSIZE << 1;

    if (block_size_min >= free_ptr) asize = csize;
    else if (asize >= PLACE_THRESHOLD) {
        SET_HDR(bp, free_ptr, 0);
        SET_FTR(bp, free_ptr, 0);
        insert(bp, free_ptr);
        bp = NEXT_BLKP(bp);
    } 
    else {
        SET_HDR(bp, asize, 1);
        SET_FTR(bp, asize, 1);
        SET_HDR(NEXT_BLKP(bp), free_ptr, 0);
        SET_FTR(NEXT_BLKP(bp), free_ptr, 0);
        insert(NEXT_BLKP(bp), free);
    }

    SET_HDR(bp, asize, 1);
    SET_FTR(bp, asize, 1);
    return bp;
}



void mm_free(void *bp) {

    if (bp == 0) return;
    size_t size = BLOCK_SIZE(bp);

    SET_HDR(bp, size, 0);
    SET_FTR(bp, size, 0);
    insert(bp, size);
    coalesce(bp);
}


void *extend_and_coalesce(void *ptr, size_t asize) {
    int left_ptr;

    // Check if the next block is free or does not exist (i.e., at the end of the heap)
    if (!GET_ALLOC(HDRP(NEXT_BLKP(ptr))) || !BLOCK_SIZE(NEXT_BLKP(ptr))) {
        left_ptr = BLOCK_SIZE(NEXT_BLKP(ptr)) + BLOCK_SIZE(ptr) - asize;
        ptr = extend_heap2(ptr, asize, &left_ptr);

        if (ptr == NULL) return NULL;

        delete(NEXT_BLKP(ptr)); // Remove the next block from the free list
        SET_HDR(ptr, asize + left_ptr, 1); // Set the header of the coalesced block
        SET_FTR(ptr, asize + left_ptr, 1); // Set the footer of the coalesced block
        return ptr;
    }

    return NULL; // Return NULL if the block could not be extended
}

void *mm_realloc(void *ptr, size_t size) {
    if (!size) return NULL;

    size_t asize, old_size, copy_size; 
    char *temp;
    void *newptr;

    // Adjusted block size to include overhead and alignment requirements
    asize = (size > DSIZE) ? ALIGN(size + DSIZE) + (1 << 7) : (DSIZE << 1) + (1 << 7);

    // If the current block is already large enough, return the original pointer
    if (BLOCK_SIZE(ptr) >= asize) return ptr;

    // Attempt to extend the current block and coalesce with the next block if possible
    void *coalesced_ptr = extend_and_coalesce(ptr, asize);
    if (coalesced_ptr != NULL) return coalesced_ptr;

    // If extension and coalescing are not possible, allocate a new block
    old_size = BLOCK_SIZE(ptr);
    copy_size = MIN(old_size, size);

    temp = mm_malloc(copy_size); // Allocate temporary memory for copying
    memcpy(temp, ptr, copy_size); // Copy the contents to the temporary memory

    mm_free(ptr); // Free the original block

    newptr = mm_malloc(size); // Allocate a new block of the desired size
    if (newptr != NULL) memcpy(newptr, temp, copy_size); // Copy the contents to the new block

    mm_free(temp); // Free the temporary memory

    return newptr; // Return the pointer to the new block
}



static void insert(char *ptr, size_t size) {
    char *cur = heap_listp;
    char *prev = 0;

    while (cur && BLOCK_SIZE(cur) < size) {
        prev = cur;
        cur = NEXT_BLK(cur);
    }
    
    if (prev == NULL) {
        heap_listp = ptr;
        SET(ptr + WSIZE, NULL);
        if (cur == NULL) {
            SET(ptr, NULL);
        } else {
            SET(ptr, cur);
            SET(cur + WSIZE, ptr);
        }
    }
    else {
        SET(ptr + WSIZE, prev);
        SET(prev, ptr);
        if (cur == NULL) {
            SET(ptr, NULL);
        } else {
            SET(ptr, cur);
            SET(cur + WSIZE, ptr);
        }
    }
}


static void delete(char *ptr) {
    char *prev_ptr = PREV_BLK(ptr);
    char *next_ptr = NEXT_BLK(ptr);

    if (prev_ptr != NULL) { // If not the first block
        SET(prev_ptr, next_ptr);
        if (next_ptr != NULL) { // If not the last block
            SET(next_ptr + WSIZE, prev_ptr);
        }
    } else { // If the first block
        heap_listp = next_ptr;
        if (heap_listp != NULL) { // If there are more blocks
            SET(heap_listp + WSIZE, NULL);
        }
    }
}


static void *coalesce(void *bp) {
    size_t prev_alloc = GET_ALLOC(FTRP(PREV_BLKP(bp)));
    size_t next_alloc = GET_ALLOC(HDRP(NEXT_BLKP(bp)));
    size_t size = BLOCK_SIZE(bp);

    if (prev_alloc && next_alloc) {         /* Case 1 */
        return bp;
    } else if (prev_alloc && !next_alloc) { /* Case 2 */
        delete(bp);
        delete(NEXT_BLKP(bp));
        size += BLOCK_SIZE(NEXT_BLKP(bp));
        SET_HDR(bp, size, 0);
        SET_FTR(bp, size, 0);
    } else if (!prev_alloc && next_alloc) { /* Case 3 */
        delete(bp);
        delete(PREV_BLKP(bp));
        size += BLOCK_SIZE(PREV_BLKP(bp));
        SET_HDR(PREV_BLKP(bp), size, 0);
        SET_FTR(bp, size, 0);
        bp = PREV_BLKP(bp);
    } else {                                /* Case 4 */
        delete(bp);
        delete(PREV_BLKP(bp));
        delete(NEXT_BLKP(bp));
        size += BLOCK_SIZE(PREV_BLKP(bp)) +
                BLOCK_SIZE(NEXT_BLKP(bp));
        SET_HDR(PREV_BLKP(bp), size, 0);
        SET_FTR(NEXT_BLKP(bp), size, 0);
        bp = PREV_BLKP(bp);
    }

    insert(bp, size);

    return bp;
}