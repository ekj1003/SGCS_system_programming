/* 
 * echoserveri.c - An iterative echo server 
 */ 
/* $begin echoserverimain */
#include "csapp.h"

typedef struct {
    int maxfd;
    fd_set read_set;
    fd_set ready_set;
    int nready;
    int maxi;
    int clientfd[FD_SETSIZE];
    rio_t clientrio[FD_SETSIZE];
}pool;

typedef struct item{
    int ID;
    int left_stock;
    int price;
    int readcnt;
    sem_t mutex;
}item;

// 트리 노드 구조체 정의
typedef struct treeNode {
    item stocks;                // 노드에 저장된 재고 데이터 (ID, left_stock, price 등을 포함한 item 구조체)
    struct treeNode* left;      // 왼쪽 하위 트리를 가리키는 포인터
    struct treeNode* right;     // 오른쪽 하위 트리를 가리키는 포인터
} treeNode;


treeNode* rootNode;
int byteCnt = 0;
int clientCnt = 0;
char response[30000];

/* functions prototype */
void echo(int connfd);
void init_pool(int listenfd, pool *p);
void add_client(int connfd, pool *p);
void check_clients(pool *p);
void showStocks();
treeNode* findStocks(treeNode* current, int ID);
void buyStocks(int ID, int stockNum);
void sellStocks(int ID, int stockNum);
treeNode* insertTree(treeNode* current, item insertedStock);
void initStocks();
void writeStocks(treeNode* current, FILE* fp);
void saveStocks();


int main(int argc, char **argv) {
    int listenfd, connfd;
    socklen_t clientlen;
    struct sockaddr_storage clientaddr;  /* Enough space for any address */  //line:netp:echoserveri:sockaddrstorage
    char client_hostname[MAXLINE], client_port[MAXLINE];
    static pool pool;

    if (argc != 2) {
	    fprintf(stderr, "usage: %s <port>\n", argv[0]);
	    exit(0);
    }
    initStocks();
    listenfd = Open_listenfd(argv[1]);
    init_pool(listenfd, &pool);
    

    while (1) {
        pool.ready_set = pool.read_set;
        pool.nready = Select(pool.maxfd + 1, &pool.ready_set, NULL, NULL, NULL);

        if(FD_ISSET(listenfd, &pool.ready_set)){
            clientlen = sizeof(struct sockaddr_storage);
            connfd = Accept(listenfd, (SA *)&clientaddr, &clientlen);
            add_client(connfd, &pool);
            Getnameinfo((SA *) &clientaddr, clientlen, client_hostname, MAXLINE, 
                    client_port, MAXLINE, 0);
            printf("Connected to (%s, %s)\n", client_hostname, client_port);
        }
	    
        check_clients(&pool);

        if(clientCnt == 0) saveStocks();
    }
    exit(0);
}


void init_pool(int listenfd, pool *p) {

    int i;
    p->maxi = -1;
    for(i = 0; i < FD_SETSIZE; i++) p->clientfd[i] = -1;

    clientCnt = 0;
    p->maxfd = listenfd;
    FD_ZERO(&p->read_set);
    FD_SET(listenfd, &p->read_set);
}

void add_client(int connfd, pool *p) {
    int i;
    p->nready--;
    for(i = 0; i < FD_SETSIZE; i++){
        if(p->clientfd[i] < 0){
            clientCnt++;
            p->clientfd[i] = connfd;
            Rio_readinitb(&p->clientrio[i], connfd);
            
            FD_SET(connfd, &p->read_set);

            if(connfd > p->maxfd) p->maxfd = connfd;
            if(i > p->maxi) p->maxi = i;
            break;
        }
    }

    /*Couldn't find and empty slot*/
    if(i == FD_SETSIZE) app_error("add_client error: Too many clients");
}

void check_clients(pool *p) {
    int i, connfd, n;
    char buf[MAXLINE];
    rio_t rio;
    
    for(i= 0; (i <= p->maxi) && (p->nready > 0); i++){
        connfd = p->clientfd[i];
        rio = p->clientrio[i];
        
        /*If the descriptor is ready, echo a text line from it*/
        if((connfd > 0) && (FD_ISSET(connfd, &p->ready_set))){
            p->nready--;
            if((n = Rio_readlineb(&rio, buf, MAXLINE)) != 0){
                /* buy, sell 명령어에 필요한 변수 */
                char cmd[20];
                int ID, stockNum;
                byteCnt += n;
                printf("Server received %d (%d total) bytes on fd %d\n", n, byteCnt, connfd);
                strcat(response, buf);
                // 1. show 명령어를 받았을 때
                if(!strcmp(buf, "show\n")) {
                    showStocks(rootNode);
                }

                // 2. exit 명령어를 받았을 때
                else if(!strcmp(buf, "exit\n")){
                    Rio_writen(connfd, response, MAXLINE);
                    clientCnt--;
                    memset(response, 0, sizeof(response));
                    return;
                }
                else{
                    sscanf(buf, "%s %d %d", cmd, &ID, &stockNum);
                    // 3. buy 명령어를 받았을 때
                    if(!strcmp(cmd, "buy")) {
                        buyStocks(ID, stockNum);
                    }
                    // 4. sell 명령어를 받았을 때
                    else if(!strcmp(cmd, "sell")) {
                        sellStocks(ID, stockNum);
                    }
                    else strcat(response, "Wrong command, try again.\n");
                }
                Rio_writen(connfd, response, MAXLINE);
                memset(response, 0, sizeof(response));
            }

            /*EOF detected, remove descriptor from pool */
            else{
                Close(connfd);
                FD_CLR(connfd, &p->read_set);
                p->clientfd[i] = -1;
                clientCnt--;
            }
        }
    }
}

void showStocks(treeNode* current) {
    if (current == NULL) return;

    // 왼쪽 자식 노드 방문
    showStocks(current->left);
    // 현재 노드 출력
    char temp[50];
    snprintf(temp, sizeof(temp), "%d %d %d\n", current->stocks.ID, current->stocks.left_stock, current->stocks.price);
    strncat(response, temp, sizeof(response) - strlen(response) - 1); // 안전하게 문자열 붙이기

    // 오른쪽 자식 노드 방문
    showStocks(current->right);
}

// 주어진 ID를 가진 재고 항목을 이진 탐색 트리에서 찾는 함수
treeNode* findStocks(treeNode* current, int ID) {
    // 현재 노드가 NULL인 경우, 재고 없음 의미.
    if (current == NULL) {
        strncat(response, "No such stock ID\n", sizeof(response) - strlen(response) - 1);
        return NULL;
    }

    // 현재 노드의 ID가 찾고자 하는 ID보다 작은 경우, 오른쪽 서브트리에서 재귀적으로 탐색
    if (current->stocks.ID < ID) {
        return findStocks(current->right, ID);
    }
    // 현재 노드의 ID가 찾고자 하는 ID보다 큰 경우, 왼쪽 서브트리에서 재귀적으로 탐색
    else if (current->stocks.ID > ID) {
        return findStocks(current->left, ID);
    }
    // 현재 노드의 ID가 찾고자 하는 ID와 같은 경우, 현재 노드 반환
    else {
        return current;
    }
}


void buyStocks(int ID, int stockNum) {
    treeNode* stockBought = findStocks(rootNode, ID);
    if (stockBought == NULL) return;

    if (stockBought->stocks.left_stock < stockNum) {
        strncat(response, "Not enough left stock\n", sizeof(response) - strlen(response) - 1);
    } else {
        stockBought->stocks.left_stock -= stockNum;
        strncat(response, "[buy] success\n", sizeof(response) - strlen(response) - 1);
    }
}

void sellStocks(int ID, int stockNum) {
    treeNode* stockSold = findStocks(rootNode, ID);
    if (stockSold == NULL) return;

    stockSold->stocks.left_stock += stockNum;
    strncat(response, "[sell] success\n", sizeof(response) - strlen(response) - 1);
}



// 트리에 새 노드를 삽입하는 함수
treeNode* insertTree(treeNode* current, item insertedStock) {
    if (current == NULL) {
        current = (treeNode*)malloc(sizeof(treeNode));
        current->stocks = insertedStock;
        current->left = NULL;
        current->right = NULL;
        return current;
    }

    if (insertedStock.ID > current->stocks.ID) {
        current->right = insertTree(current->right, insertedStock);
    } else if (insertedStock.ID < current->stocks.ID) {
        current->left = insertTree(current->left, insertedStock);
    }

    return current;
}

// 재고 데이터를 초기화하는 함수
void initStocks() {
    FILE* fp = fopen("stock.txt", "r");
    if (fp == NULL) {
        perror("Error opening file");
        return;
    }

    item currentItem;
    while (fscanf(fp, "%d %d %d", &currentItem.ID, &currentItem.left_stock, &currentItem.price) != EOF) {
        currentItem.readcnt = 0;
        rootNode = insertTree(rootNode, currentItem);
    }

    fclose(fp);
}

// 재고 데이터를 파일에 쓰는 재귀 함수
// 현재 노드를 기준으로 왼쪽 하위 트리와 오른쪽 하위 트리의 모든 노드를 재귀적으로 탐색하여 파일에 재고 데이터 쓰기
void writeStocks(treeNode* current, FILE* fp) {
    if (current == NULL) return;
    
    // 현재 노드의 재고 데이터를 파일에 쓰기
    fprintf(fp, "%d %d %d\n", current->stocks.ID, current->stocks.left_stock, current->stocks.price);
    
    // 왼쪽 하위 트리 탐색 및 파일 쓰기
    writeStocks(current->left, fp);
    
    // 오른쪽 하위 트리 탐색 및 파일 쓰기
    writeStocks(current->right, fp);
}

// 재고 데이터를 파일에 저장하는 함수
// 루트 노드부터 시작하여 트리를 탐색하며 모든 노드의 재고 데이터를 "stock.txt" 파일에 저장
void saveStocks() {
    FILE* fp = fopen("stock.txt", "w");
    
    if (fp == NULL) {
        perror("Error opening file");
        return;
    }

    // 루트 노드부터 시작하여 재고 데이터를 파일에 쓰기
    writeStocks(rootNode, fp);

    if (fclose(fp) != 0) {
        perror("Error closing file");
    }
}

/* $end echoserverimain */
