/* 
 * echoserveri.c - An iterative echo server 
 */ 
/* $begin echoserverimain */
#include "csapp.h"

typedef struct item{
    int ID;
    int left_stock;
    int price;
    int readCnt;
    sem_t mutex;
}item;

// 트리 노드 구조체 정의
typedef struct treeNode {
    item stocks;                // 노드에 저장된 재고 데이터 (ID, left_stock, price 등을 포함한 item 구조체)
    struct treeNode* left;      // 왼쪽 하위 트리를 가리키는 포인터
    struct treeNode* right;     // 오른쪽 하위 트리를 가리키는 포인터
} treeNode;

treeNode* rootNode;
sem_t mutex, client_mutex;
int byteCnt = 0;
int clientCnt = 0;
int readCnt = 0;
char response[30000];

/* functions prototype */
void echo(int connfd);
void check_threads(int connfd, char* buf);
void handle_client(int connfd);
void *thread(void *vargp);
void showStocks(treeNode* current);
treeNode* findStocks(treeNode* current, int ID);
void buyStocks(int ID, int stockNum);
void sellStocks(int ID, int stockNum);
treeNode* insertTree(treeNode* current, item insertedStock);
void initStocks();
void writeStocks(treeNode* current, FILE* fp);
void saveStocks();

int main(int argc, char **argv) {
    int listenfd;
    socklen_t clientlen;
    struct sockaddr_storage clientaddr;
    char client_hostname[MAXLINE], client_port[MAXLINE];
    pthread_t tid;

    if (argc != 2) {
        fprintf(stderr, "usage: %s <port>\n", argv[0]);
        exit(0);
    }

    Sem_init(&mutex, 0, 1);
    Sem_init(&client_mutex, 0, 1);

    initStocks();
    listenfd = Open_listenfd(argv[1]);

    while (1) {
        clientlen = sizeof(struct sockaddr_storage);
        int *connfdp = Malloc(sizeof(int));
        if (connfdp == NULL) {
            perror("Malloc error");
            exit(1);
        }
        *connfdp = Accept(listenfd, (SA *) &clientaddr, &clientlen);
        Getnameinfo((SA *) &clientaddr, clientlen, client_hostname, MAXLINE, client_port, MAXLINE, 0);
        printf("Connected to (%s, %s)\n", client_hostname, client_port);

        P(&client_mutex);
        clientCnt++;
        V(&client_mutex);

        Pthread_create(&tid, NULL, thread, connfdp);
    }

    exit(0);
}

void *thread(void *vargp) {
    int connfd = *((int *)vargp);
    Pthread_detach(pthread_self());
    Free(vargp);

    handle_client(connfd);

    Close(connfd);
    P(&client_mutex);
    clientCnt--;
    V(&client_mutex);

    P(&client_mutex);
    if (clientCnt == 0) {
        saveStocks();
    }
    V(&client_mutex);

    return NULL;
}



// int main(int argc, char **argv) {
//     int listenfd, *connfdp;
//     socklen_t clientlen;
//     struct sockaddr_storage clientaddr;  /* Enough space for any address */  //line:netp:echoserveri:sockaddrstorage
//     char client_hostname[MAXLINE], client_port[MAXLINE];
//     pthread_t tid;


//     if (argc != 2) {
// 	    fprintf(stderr, "usage: %s <port>\n", argv[0]);
// 	    exit(0);
//     }

//     Sem_init(&mutex, 0, 1);
//     Sem_init(&client_mutex, 0, 1);

//     initStocks();
//     listenfd = Open_listenfd(argv[1]);
    
//     while (1) {

//         clientlen = sizeof(struct sockaddr_storage);
//         connfdp = Malloc(sizeof(int));
//         *connfdp = Accept(listenfd, (SA *) &clientaddr, &clientlen);
//         Getnameinfo((SA *) &clientaddr, clientlen, client_hostname, MAXLINE, 
//                  client_port, MAXLINE, 0);
//         printf("Connected to (%s, %s)\n", client_hostname, client_port);
        
//         Pthread_create(&tid, NULL, thread, connfdp);

//         P(&client_mutex);
//         clientCnt++;
//         V(&client_mutex);

//         if(clientCnt == 0) saveStocks();

//         saveStocks();
//     }
//     saveStocks();

//     exit(0);
// }


// void *thread(void *vargp) {
//     int connfd = *((int *)vargp);
//     Pthread_detach(pthread_self());
//     Free(vargp);

//     handle_client(connfd);

//     Close(connfd);
//     P(&client_mutex);
//     clientCnt--;
//     V(&client_mutex);
//     return NULL;
// }

void handle_client(int connfd) {
    int n;
    char buf[MAXLINE];
    rio_t rio;

    Rio_readinitb(&rio, connfd);

    while ((n = Rio_readlineb(&rio, buf, MAXLINE)) != 0) {
        char cmd[20];
        int ID, stockNum;

        P(&client_mutex);
        byteCnt += n;
        printf("Server received %d (%d total) bytes on fd %d\n", n, byteCnt, connfd);
        V(&client_mutex);

        memset(response, 0, sizeof(response));

        if (!strcmp(buf, "show\n")) {
            P(&mutex);
            showStocks(rootNode);
            V(&mutex);
        } else if (!strcmp(buf, "exit\n")) {
            break;
        } else {

            sscanf(buf, "%s %d %d", cmd, &ID, &stockNum);
            if (!strcmp(cmd, "buy")) {
                P(&client_mutex);
                buyStocks(ID, stockNum);
                V(&client_mutex);
            } else if (!strcmp(cmd, "sell")) {
                P(&client_mutex);
                sellStocks(ID, stockNum);
                V(&client_mutex);
            } else {
                strncat(response, "Wrong cmd, try again.\n", sizeof(response) - strlen(response) - 1);
            }
        }

        Rio_writen(connfd, response, MAXLINE);
    }

    saveStocks();
}

// void check_threads(int connfd, char* buf) {

//     if(!strcmp(buf, "show\n")){
//         P(&mutex);
//         readCnt++;
//         if(readCnt == 1) P(&client_mutex);
//         V(&mutex);
        
//         strcat(response, buf);
//         showStocks(rootNode);

//         P(&mutex);
//         readCnt--;
//         if(readCnt == 0) V(&client_mutex);
//         V(&mutex);

//         Rio_writen(connfd, response, MAXLINE);
//         memset(response, 0, sizeof(response));
        
//     }
//     else if(!strcmp(buf, "exit\n")){
//         strcat(response, buf);
//         Rio_writen(connfd, response, MAXLINE);
//         memset(response, 0, sizeof(response));
//         return;
//     }
//     else{
//         char cmd[20];
//         int ID;
//         int stockNum;

//         sscanf(buf, "%s %d %d", cmd, &ID, &stockNum);
//         if(!strcmp(cmd, "buy")) {
//             P(&client_mutex);
//             strcat(response, buf);
//             buyStocks(ID, stockNum);
//             V(&client_mutex);
//         }
//         else if(!strcmp(cmd, "sell")){
//             P(&client_mutex);
//             strcat(response, buf);
//             sellStocks(ID, stockNum);
//             V(&client_mutex);
//         } 
//         else {
//             strcat(response, buf);
//             strcat(response, "Wrong cmd, try again.\n");
//         }
//         Rio_writen(connfd, response, MAXLINE);
//         memset(response, 0, sizeof(response));
//     }
// }
// void *thread(void *vargp) {
//     int connfd = *((int *)vargp);
//     int n;
//     Pthread_detach(pthread_self());
//     Free(vargp);

//     char buf[MAXLINE];
//     rio_t rio;

//     Rio_readinitb(&rio, connfd);
    
//     while((n = Rio_readlineb(&rio, buf, MAXLINE)) != 0){
//         P(&client_mutex);
//         byteCnt += n;
//         printf("Server received %d (%d total) bytes on fd %d\n", n, byteCnt, connfd);
//         V(&client_mutex);

        
//         check_threads(connfd, buf);
//     }
//     Close(connfd);
//     saveStocks();
//     P(&client_mutex);
//     clientCnt--;
//     V(&client_mutex);
//     return NULL;
// }





void showStocks(treeNode* current) {
    if (current == NULL) return;

    // 왼쪽 자식 노드 방문
    showStocks(current->left);
    // 현재 노드 출력
    char temp[50];
    snprintf(temp, sizeof(temp), "%d %d %d\n", current->stocks.ID, current->stocks.left_stock, current->stocks.price);
    strncat(response, temp, sizeof(response) - strlen(response) - 1); // 안전하게 문자열 붙이기

    // 오른쪽 자식 노드 방문
    showStocks(current->right);
}

// 주어진 ID를 가진 재고 항목을 이진 탐색 트리에서 찾는 함수
treeNode* findStocks(treeNode* current, int ID) {
    // 현재 노드가 NULL인 경우, 재고 없음 의미.
    if (current == NULL) {
        strncat(response, "No such stock ID\n", sizeof(response) - strlen(response) - 1);
        return NULL;
    }

    // 현재 노드의 ID가 찾고자 하는 ID보다 작은 경우, 오른쪽 서브트리에서 재귀적으로 탐색
    if (current->stocks.ID < ID) {
        return findStocks(current->right, ID);
    }
    // 현재 노드의 ID가 찾고자 하는 ID보다 큰 경우, 왼쪽 서브트리에서 재귀적으로 탐색
    else if (current->stocks.ID > ID) {
        return findStocks(current->left, ID);
    }
    // 현재 노드의 ID가 찾고자 하는 ID와 같은 경우, 현재 노드 반환
    else {
        return current;
    }
}

// 주어진 ID를 가진 주식 항목을 구매하는 함수
// ID와 구매할 주식 수량을 입력받아 재고를 업데이트
void buyStocks(int ID, int stockNum) {
    // 주어진 ID를 가진 주식 항목을 트리에서 찾음
    treeNode* stockBought = findStocks(rootNode, ID);
    if (stockBought == NULL) return;

    // 구매할 수량이 남은 재고보다 많은 경우
    if ((stockBought->stocks).left_stock < stockNum) {
        strncat(response, "Not enough left stock\n", sizeof(response) - strlen(response) - 1);
    } else {
        // 주식 항목의 뮤텍스를 사용하여 재고 업데이트를 동기화
        P(&((stockBought->stocks).mutex));
        (stockBought->stocks).left_stock -= stockNum;
        V(&((stockBought->stocks).mutex));

        // 구매 성공 메시지 추가
        strncat(response, "[buy] success\n", sizeof(response) - strlen(response) - 1);
    }
}

// 주어진 ID를 가진 주식 항목을 판매하는 함수
// ID와 판매할 주식 수량을 입력받아 재고를 업데이트
void sellStocks(int ID, int stockNum) {
    // 주어진 ID를 가진 주식 항목을 트리에서 찾음
    treeNode* stockSold = findStocks(rootNode, ID);
    if (stockSold == NULL) return;

    // 주식 항목의 뮤텍스를 사용하여 재고 업데이트를 동기화
    P(&((stockSold->stocks).mutex));
    (stockSold->stocks).left_stock += stockNum;
    V(&((stockSold->stocks).mutex));

    // 판매 성공 메시지 추가
    strncat(response, "[sell] success\n", sizeof(response) - strlen(response) - 1);
}

// 트리에 새 노드를 삽입하는 함수
treeNode* insertTree(treeNode* current, item insertedStock) {
    if (current == NULL) {
        current = (treeNode*)malloc(sizeof(treeNode));
        current->stocks = insertedStock;
        current->left = NULL;
        current->right = NULL;
        return current;
    }

    if (insertedStock.ID > current->stocks.ID) {
        current->right = insertTree(current->right, insertedStock);
    } else if (insertedStock.ID < current->stocks.ID) {
        current->left = insertTree(current->left, insertedStock);
    }

    return current;
}

// 재고 데이터를 초기화하는 함수
void initStocks() {
    FILE *fp = fopen("stock.txt", "r");
    if (fp == NULL) {
        perror("Error opening file");
        exit(1);
    }

    item currentItem;
    rootNode = NULL; // 루트 노드를 NULL로 초기화

    while (fscanf(fp, "%d %d %d", &currentItem.ID, &currentItem.left_stock, &currentItem.price) != EOF) {
        currentItem.readCnt = 0;
        Sem_init(&currentItem.mutex, 0, 1);
        rootNode = insertTree(rootNode, currentItem);
    }

    fclose(fp);
}



// 재고 데이터를 파일에 쓰는 재귀 함수
// 현재 노드를 기준으로 왼쪽 하위 트리와 오른쪽 하위 트리의 모든 노드를 재귀적으로 탐색하여 파일에 재고 데이터 쓰기
void writeStocks(treeNode* current, FILE* fp) {
    if (current == NULL) return;
    
    // 현재 노드의 재고 데이터를 파일에 쓰기
    fprintf(fp, "%d %d %d\n", current->stocks.ID, current->stocks.left_stock, current->stocks.price);
    
    // 왼쪽 하위 트리 탐색 및 파일 쓰기
    writeStocks(current->left, fp);
    
    // 오른쪽 하위 트리 탐색 및 파일 쓰기
    writeStocks(current->right, fp);
}


// 재고 데이터를 파일에 저장하는 함수
// 루트 노드부터 시작하여 트리를 탐색하며 모든 노드의 재고 데이터를 "stock.txt" 파일에 저장
void saveStocks() {
    FILE* fp = fopen("stock.txt", "w");
    
    if (fp == NULL) {
        perror("Error opening file");
        return;
    }

    // 루트 노드부터 시작하여 재고 데이터를 파일에 쓰기
    writeStocks(rootNode, fp);

    if (fclose(fp) != 0) {
        perror("Error closing file");
    }
}
/* $end echoserverimain */
