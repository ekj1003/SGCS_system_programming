#include "bitmap.h"
#include "debug.h"
#include "hash.h"
#include "hex_dump.h"
#include <string.h>
#include "limits.h"
#include "list.h"
#include "round.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAX_INPUT_SIZE 100
#define MAX_ARGS 20
#define MAX_SIZE 10

// Data structures for lists, hash tables, and bitmaps
struct list List[MAX_SIZE];
struct hash Hash[MAX_SIZE];
struct bitmap Bitmap[MAX_SIZE];

// Global indices for each data structure type
int list_idx;
int bm_idx;
int hash_idx;

// Function to extract type from the name (e.g., list0 -> list)
char *extract_type(const char *name)
{
    /*
        delete list0
        delete hash0
        delete bm0
        name: list0 -> type: list, index = 0
        name: hash0 -> type: hash, index = 0
        name: bm0 -> type: bm, index = 0
    */
    int len = strcspn(name, "0123456789");

    char *type = (char *)malloc(len + 1);
    if (type == NULL)
    {
        exit(1);
    }
    strncpy(type, name, len);
    type[len] = '\0';

    return type;
}

// Function to extract index from the name (e.g., list0 -> 0)
int extract_index(const char *name)
{
    int idx;
    if (strlen(name) == 5)
        idx = name[4] - '0';
    else if (strlen(name) == 3)
        idx = name[2] - '0';
    return idx;
}

int main()
{
    char input[MAX_INPUT_SIZE];
    char *argv[MAX_ARGS] = {NULL};
    int argc = 0;

    while (1)
    {

        fgets(input, MAX_INPUT_SIZE, stdin);

        input[strcspn(input, "\n")] = '\0';

        argc = 0;

        // Tokenize input command
        char *token = strtok(input, " ");
        while (token != NULL && argc < MAX_ARGS)
        {
            argv[argc] = token;
            token = strtok(NULL, " ");
            argc += 1;
        }
        char *cmd = argv[0]; // Extract command
        char *name;
        char *type;

        /* Bitmap variables */
        struct bitmap *bm;
        size_t start;
        size_t cnt;
        
        /* quit */
        if (strcmp(cmd, "quit") == 0)
            break;

        /* create list, hashtable, bitmap */
        else if (strcmp(cmd, "create") == 0)
        {
            type = argv[1];
            name = argv[2];

            if (strcmp(type, "list") == 0)
            {
                list_idx = extract_index(name);
                if (list_idx < MAX_SIZE)
                {
                    list_init(&List[list_idx]);
                }
            }
            else if (strcmp(type, "hashtable") == 0)
            {
                hash_idx = extract_index(name);
                if (hash_idx < MAX_SIZE)
                {
                        struct hash *new_hash = &Hash[hash_idx];
                        hash_init(new_hash, hash_func, less_func, NULL);
                }
            }
            else if (strcmp(type, "bitmap") == 0)
            {
                int size = atoi(argv[3]);
                bm_idx = extract_index(name);
                if (bm_idx < MAX_SIZE)
                {
                    Bitmap[bm_idx] = *bitmap_create(size);
                }
            }
        }

        /* delete list, hashtable, bitmap */
        else if (strcmp(cmd, "delete") == 0)
        {
            name = argv[1];
            type = extract_type(name);
            int index = extract_index(name);

            if (index < MAX_SIZE)
            {
                if (strcmp(type, "list") == 0)
                {
                        struct list_elem *e;
                        while (!list_empty(&List[index]))
                        {
                            e = list_pop_front(&List[index]);
                            free(e);
                        }
                }
                else if (strcmp(type, "hash") == 0)
                {
                        hash_clear(&Hash[index], NULL);
                }
                else if (strcmp(type, "bm") == 0)
                {
                    Bitmap[index] = *bitmap_create(0);
                }
            }
        }

        /* dumpdata list, hashtable, bitmap */
        else if (strcmp(cmd, "dumpdata") == 0)
        {
            name = argv[1];
            type = extract_type(name);

            if (strcmp(type, "list") == 0)
            {
                list_idx = extract_index(name);
                struct list_elem *e;

                for (e = list_begin(&List[list_idx]); e != list_end(&List[list_idx]); e = list_next(e))
                {
                    struct list_item *item = list_entry(e, struct list_item, elem);
                    printf("%d ", item->data);
                }
                printf("\n");
            }
            else if (strcmp(type, "hash") == 0)
            {
                hash_idx = extract_index(name);
                struct hash *hash_table = &Hash[hash_idx];
                struct hash_iterator it;
                hash_first(&it, hash_table);

                while (hash_next(&it))
                {
                    struct hash_elem *e = hash_cur(&it);
                    printf("%d ", e->value);
                }
                printf("\n");
            }
            else if (strcmp(type, "bm") == 0)
            {
                bm_idx = extract_index(name);
                struct bitmap *bm = &Bitmap[bm_idx];
                for (size_t i = 0; i < bm->bit_cnt; i++)
                {
                    if (bitmap_test(bm, i))
                        printf("1");
                    else
                        printf("0");
                }
                printf("\n");
            }
        }

        /* list command */
        else if (strcmp(cmd, "list_push_front") == 0)
        {
            name = argv[1];
            list_idx = extract_index(name);
            int value = atoi(argv[2]);

            struct list_item *new_item = (struct list_item *)malloc(sizeof(struct list_item));
            if (new_item != NULL)
            {
                new_item->data = value;
                list_push_front(&List[list_idx], &new_item->elem);
            }
        }
        else if (strcmp(cmd, "list_push_back") == 0)
        {
            name = argv[1];
            list_idx = extract_index(name);
            int value = atoi(argv[2]);

            struct list_item *new_item = (struct list_item *)malloc(sizeof(struct list_item));
            if (new_item != NULL)
            {
                new_item->data = value;
                list_push_back(&List[list_idx], &new_item->elem);
            }
        }
        else if (strcmp(cmd, "list_front") == 0)
        {
            name = argv[1];
            list_idx = extract_index(name);
            struct list_elem *front_elem = list_front(&List[list_idx]);
            struct list_item *front_item = list_entry(front_elem, struct list_item, elem);
            printf("%d\n", front_item->data);
        }

        else if (strcmp(cmd, "list_back") == 0)
        {
            name = argv[1];
            list_idx = extract_index(name);
            struct list_elem *front_elem = list_back(&List[list_idx]);
            struct list_item *front_item = list_entry(front_elem, struct list_item, elem);
            printf("%d\n", front_item->data);
        }

        else if (strcmp(cmd, "list_pop_front") == 0)
        {
            name = argv[1];
            list_idx = extract_index(name);
            struct list_elem *removed_elem = list_pop_front(&List[list_idx]);
            struct list_item *removed_item = list_entry(removed_elem, struct list_item, elem);
            free(removed_item);
        }
        else if (strcmp(cmd, "list_pop_back") == 0)
        {
            name = argv[1];
            list_idx = extract_index(name);
            struct list_elem *removed_elem = list_pop_back(&List[list_idx]);
            struct list_item *removed_item = list_entry(removed_elem, struct list_item, elem);
            free(removed_item);
        }
        else if (strcmp(cmd, "list_insert") == 0)
        {
            name = argv[1];
            list_idx = extract_index(name);
            int idx_mov = atoi(argv[2]);
            int value = atoi(argv[3]);
            struct list_elem *e;
            int count = 0;
            for (e = list_begin(&List[list_idx]); e != list_end(&List[list_idx]); e = list_next(e))
            {
                if (count == idx_mov)
                    break;
                count++;
            }
            struct list_item *new_item = (struct list_item *)malloc(sizeof(struct list_item));
            if (new_item != NULL)
            {
                new_item->data = value;
                list_insert(e, &new_item->elem);
            }
        }
        else if (strcmp(cmd, "list_insert_ordered") == 0)
        {
            name = argv[1];
            list_idx = extract_index(name);
            int value = atoi(argv[2]);

            struct list_item *new_item = (struct list_item *)malloc(sizeof(struct list_item));
            if (new_item != NULL)
            {
                new_item->data = value;
                list_insert_ordered(&List[list_idx], &new_item->elem, list_less, NULL);
            }
        }

        else if (strcmp(cmd, "list_remove") == 0)
        {
            name = argv[1];
            list_idx = extract_index(name);
            int index_removed = atoi(argv[2]);

            struct list_elem *e = list_begin(&List[list_idx]);
            int count = 0;
            while (e != list_end(&List[list_idx]) && count < index_removed)
            {
                e = list_next(e);
                count++;
            }
            if (count == index_removed && e != list_end(&List[list_idx]))
            {
                e->prev->next = e->next;
                e->next->prev = e->prev;
                free(e);
            }
        }
        else if (strcmp(cmd, "list_reverse") == 0)
        {
            name = argv[1];
            list_idx = extract_index(name);
            list_reverse(&List[list_idx]);
        }
        else if (strcmp(cmd, "list_sort") == 0)
        {
            name = argv[1];
            list_idx = extract_index(name);
            list_sort(&List[list_idx], list_less, NULL);
        }
        else if (strcmp(cmd, "list_size") == 0)
        {
            name = argv[1];
            list_idx = extract_index(name);
            size_t size = list_size(&List[list_idx]);
            printf("%zu\n", size);
        }
        else if (strcmp(cmd, "list_empty") == 0)
        {
            name = argv[1];
            list_idx = extract_index(name);
            bool empty = list_empty(&List[list_idx]);
            printf("%s\n", empty ? "true" : "false");
        }
        else if (strcmp(cmd, "list_max") == 0)
        {
            name = argv[1];
            list_idx = extract_index(name);
            struct list_elem *max_elem = list_max(&List[list_idx], &list_less, NULL);
            struct list_item *max_item = list_entry(max_elem, struct list_item, elem);
            printf("%d\n", max_item->data);
        }
        else if (strcmp(cmd, "list_min") == 0)
        {
            name = argv[1];
            list_idx = extract_index(name);
            struct list_elem *min_elem = list_min(&List[list_idx], &list_less, NULL);
            struct list_item *min_item = list_entry(min_elem, struct list_item, elem);
            printf("%d\n", min_item->data);
        }
        else if (strcmp(cmd, "list_splice") == 0)
        {
            int idx1, idxf, idxl, list0_index, list1_index;
            char *list0_name = argv[1];
            idx1 = atoi(argv[2]);
            char *list1_name = argv[3];
            idxf = atoi(argv[4]);
            idxl = atoi(argv[5]);
            list0_index = extract_index(list0_name);
            list1_index = extract_index(list1_name);

            struct list_elem *before = list_begin(&List[list0_index]);
            for (int i = 0; i < idx1; i++)
            {
                before = list_next(before);
                if (before == list_end(&List[list0_index]))
                {
                    fprintf(stderr, "out of range\n");
                    exit(EXIT_FAILURE);
                }
            }

            struct list_elem *first = list_begin(&List[list1_index]);
            for (int i = 0; i < idxf; i++)
            {
                first = list_next(first);
                if (first == list_end(&List[list1_index]))
                {
                    fprintf(stderr, "out of range\n");
                    exit(EXIT_FAILURE);
                }
            }

            struct list_elem *last = list_begin(&List[list1_index]);
            for (int i = 0; i < idxl; i++)
            {
                last = list_next(last);
                if (last == list_end(&List[list1_index]))
                {
                    fprintf(stderr, "out of range\n");
                    exit(EXIT_FAILURE);
                }
            }

            while (first != last)
            {
                struct list_elem *next = list_next(first);
                list_remove(first);
                list_insert(before, first);
                first = next;
            }
        }
        else if (strcmp(cmd, "list_shuffle") == 0)
        {
            name = argv[1];
            list_idx = extract_index(name);

            list_shuffle(&List[list_idx]);
        }
        else if (strcmp(cmd, "list_swap") == 0)
        {
            int index1, index2;
            name = argv[1];
            list_idx = extract_index(name);
            index1 = atoi(argv[2]);
            index2 = atoi(argv[3]);

            struct list *list = &List[list_idx];
            struct list_elem *a = list_begin(list);
            struct list_elem *b = list_begin(list);
            for (int i = 0; i < index1; i++)
                a = list_next(a);
            for (int i = 0; i < index2; i++)
                b = list_next(b);
            list_swap(a, b);
        }
        else if (strcmp(cmd, "list_unique") == 0)
        {
            char *list_name = argv[1];
            char *dest_list_name = argv[2];
            

            if (argc == 2)
            {
                list_idx = extract_index(list_name);
                list_unique(&List[list_idx], NULL, list_less, NULL);
            }
            else if (argc == 3)
            {
                int dest_list_idx = extract_index(dest_list_name);
                list_idx = extract_index(list_name);
                list_unique(&List[list_idx], &List[dest_list_idx], list_less, NULL);
            }
        }

        /* hash command */
        else if (strcmp(input, "hash_insert") == 0)
        {
            name = argv[1];
            hash_idx = extract_index(name);
            int value = atoi(argv[2]);

            struct hash_elem *e = (struct hash_elem *)malloc(sizeof(struct hash_elem));
            if (e != NULL)
            {
                e->value = value;
                struct hash *hash_table = &Hash[hash_idx];

                struct hash_elem *old = hash_insert(hash_table, e);
                if (old != NULL)
                    free(e);
            }
        }

        else if (strcmp(input, "hash_apply") == 0)
        {
            char *name = argv[1];
            char *action = argv[2];

            hash_idx = extract_index(name);

            struct hash *hash_table = &Hash[hash_idx];

            if (strcmp(action, "square") == 0)
            {
                hash_apply(hash_table, square_hash_elem);
            }
            else if (strcmp(action, "triple") == 0)
            {
                hash_apply(hash_table, cube_hash_elem);
            }
        }
        else if (strcmp(input, "hash_delete") == 0)
        {
            name = argv[1];
            hash_idx = extract_index(name);
            int value = atoi(argv[2]);

            struct hash_elem *e = (struct hash_elem *)malloc(sizeof(struct hash_elem));
            if (e != NULL)
            {
                e->value = value;
                struct hash *hash_table = &Hash[hash_idx];
                struct hash_elem *deleted = hash_delete(hash_table, e);

                if (deleted != NULL)
                {
                    free(deleted);
                }
            }
        }
        else if (strcmp(input, "hash_empty") == 0)
        {
            name = argv[1];
            hash_idx = extract_index(name);
            struct hash *hash_table = &Hash[hash_idx];
            bool is_empty = hash_empty(hash_table);

            if (is_empty)
            {
                printf("true\n");
            }
            else
            {
                printf("false\n");
            }
        }
        else if (strcmp(input, "hash_size") == 0)
        {
            name = argv[1];
            hash_idx = extract_index(name);
            struct hash *hash_table = &Hash[hash_idx];
            size_t size = hash_size(hash_table);
            printf("%zu\n", size);
        }
        else if (strcmp(input, "hash_clear") == 0)
        {
            name = argv[1];
            hash_idx = extract_index(name);

            struct hash *hash_table = &Hash[hash_idx];
            hash_clear(hash_table, destructor);
        }
        else if (strcmp(input, "hash_find") == 0)
        {
            name = argv[1];
            int key = atoi(argv[2]);
            hash_idx = extract_index(name);
            struct hash *hash_table = &Hash[hash_idx];
            struct hash_elem e;
            e.value = key;

            struct hash_elem *found_elem = hash_find(hash_table, &e);

            if (found_elem != NULL)
            {
                printf("%d\n", key);
            }
            else
            {
                printf("\n");
            }
        }

        else if (strcmp(input, "hash_replace") == 0)
        {
            name = argv[1];
            int value = atoi(argv[2]);
            hash_idx = extract_index(name);

            struct hash *hash_table = &Hash[hash_idx];

            struct hash_elem *new_elem = (struct hash_elem *)malloc(sizeof(struct hash_elem));
            new_elem->value = value;

            hash_replace(hash_table, new_elem);
        }

        else if (strcmp(input, "hash_int_2") == 0)
        {
            name = argv[1];
            int value = atoi(argv[2]);

            printf("%u\n", hash_int_2(value));
        }

        /* bitmap command */
        else if (strcmp(input, "bitmap_mark") == 0)
        {
            name = argv[1];
            bm_idx = extract_index(name);
            int value = atoi(argv[2]);
            bm = &Bitmap[bm_idx];
            bitmap_mark(bm, value);
        }
        else if (strcmp(input, "bitmap_all") == 0)
        {
            name = argv[1];
            start = atoi(argv[2]);
            cnt = atoi(argv[3]);

            bm_idx = extract_index(name);
            bm = &Bitmap[bm_idx];
            bool all_set = bitmap_all(bm, start, cnt);
            printf("%s\n", all_set ? "true" : "false");
        }
        else if (strcmp(input, "bitmap_any") == 0)
        {
            name = argv[1];
            start = atoi(argv[2]);
            cnt = atoi(argv[3]);

            bm_idx = extract_index(name);
            bm = &Bitmap[bm_idx];
            bool result = bitmap_any(bm, start, cnt);
            printf("%s\n", result ? "true" : "false");
        }
        else if (strcmp(input, "bitmap_contains") == 0)
        {
            name = argv[1];
            start = atoi(argv[2]);
            cnt = atoi(argv[3]);
            bool value = strcmp(argv[4], "true") == 0 ? true : false;

            bm_idx = extract_index(name);
            bm = &Bitmap[bm_idx];
            bool result = bitmap_contains(bm, start, cnt, value);
            printf("%s\n", result ? "true" : "false");
        }
        else if (strcmp(input, "bitmap_count") == 0)
        {
            name = argv[1];
            start = atoi(argv[2]);
            cnt = atoi(argv[3]);
            bool value = strcmp(argv[4], "true") == 0 ? true : false;

            bm_idx = extract_index(name);
            bm = &Bitmap[bm_idx];
            size_t result = bitmap_count(bm, start, cnt, value);
            printf("%zu\n", result);
        }
        else if (strcmp(input, "bitmap_dump") == 0)
        {
            name = argv[1];

            bm_idx = extract_index(name);
            bm = &Bitmap[bm_idx];
            bitmap_dump(bm);
        }
        else if (strcmp(input, "bitmap_expand") == 0)
        {
            name = argv[1];
            int size = atoi(argv[2]);

            bm_idx = extract_index(name);
            bm = &Bitmap[bm_idx];
            bitmap_expand(bm, size);
        }
        else if (strcmp(input, "bitmap_flip") == 0)
        {
            name = argv[1];
            int bit_index = atoi(argv[2]);

            bm_idx = extract_index(name);
            bm = &Bitmap[bm_idx];
            bitmap_flip(bm, bit_index);
        }
        else if (strcmp(input, "bitmap_none") == 0)
        {
            name = argv[1];
            start = atoi(argv[2]);
            cnt = atoi(argv[3]);

            bm_idx = extract_index(name);
            bm = &Bitmap[bm_idx];
            printf("%s\n", bitmap_none(bm, start, cnt) ? "true" : "false");
        }
        else if (strcmp(input, "bitmap_reset") == 0)
        {
            name = argv[1];
            int bit_index = atoi(argv[2]);

            bm_idx = extract_index(name);
            bm = &Bitmap[bm_idx];
            bitmap_reset(bm, bit_index);
        }
        else if (strcmp(input, "bitmap_scan_and_flip") == 0)
        {
            name = argv[1];
            size_t start = atoi(argv[2]);
            size_t cnt = atoi(argv[3]);
            bool value = (strcmp(argv[4], "true") == 0) ? true : false;

            bm_idx = extract_index(name);
            bm = &Bitmap[bm_idx];
            size_t idx = bitmap_scan_and_flip(bm, start, cnt, value);
            printf("%zu\n", idx);
        }
        else if (strcmp(input, "bitmap_scan") == 0)
        {
            name = argv[1];
            size_t start = atoi(argv[2]);
            size_t cnt = atoi(argv[3]);
            bool value = (strcmp(argv[4], "true") == 0) ? true : false;

            bm_idx = extract_index(name);
            bm = &Bitmap[bm_idx];
            size_t idx = bitmap_scan(bm, start, cnt, value);
            printf("%zu\n", idx);
        }
        else if (strcmp(input, "bitmap_set_all") == 0)
        {
            name = argv[1];
            bool value = (strcmp(argv[2], "true") == 0) ? true : false;

            bm_idx = extract_index(name);
            bm = &Bitmap[bm_idx];
            bitmap_set_all(bm, value);
        }
        else if (strcmp(input, "bitmap_set_multiple") == 0)
        {
            name = argv[1];
            start = atoi(argv[2]);
            cnt = atoi(argv[3]);
            bool value = (strcmp(argv[4], "true") == 0) ? true : false;

            bm_idx = extract_index(name);
            bm = &Bitmap[bm_idx];
            bitmap_set_multiple(bm, start, cnt, value);
        }
        else if (strcmp(input, "bitmap_set") == 0)
        {
            name = argv[1];
            size_t idx = atoi(argv[2]);
            bool value = (strcmp(argv[3], "true") == 0) ? true : false;

            bm_idx = extract_index(name);
            bm = &Bitmap[bm_idx];
            bitmap_set(bm, idx, value);
        }
        else if (strcmp(input, "bitmap_size") == 0)
        {
            name = argv[1];

            bm_idx = extract_index(name);
            bm = &Bitmap[bm_idx];
            size_t size = bitmap_size(bm);
            printf("%zu\n", size);
        }
        else if (strcmp(input, "bitmap_test") == 0)
        {
            name = argv[1];
            size_t idx = atoi(argv[2]);

            bm_idx = extract_index(name);
            bm = &Bitmap[bm_idx];
            bool result = bitmap_test(bm, idx);
            printf("%s\n", result ? "true" : "false");
        }
    }
    return 0;
}
