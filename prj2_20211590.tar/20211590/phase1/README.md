[system programming lecture]

-project 2 baseline

csapp.{c,h}
        CS:APP3e functions

shellex.c
        Simple shell example

phase1
Execvp 함수를 사용하여 linux의 명령어(cd, ls, touch, cat, echo, mkdir, rmdir)을 구현한다. 
이 명령어 뒤에 옵션들을 추가하여 실행시킬 수 있다. 
올바르지 않은 명령어가 입력으로 들어올 경우 error 처리 또한 진행한다.


./myshell로 실행시킬 수 있다.
