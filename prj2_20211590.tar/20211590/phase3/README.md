[system programming lecture]

-project 2 baseline

csapp.{c,h}
        CS:APP3e functions

shellex.c
        Simple shell example

phase3
Program의 backround 실행을 구현한다. 
Phase1, 2에서 구현한 명령어 뒤에 &을 입력하면 background로 인식하도록 한다. 
jobs 명령어(background의 정보(cmdline, state) 출력), bg, fg, kill 명령으로 background process의 상태를 변경한다. 
ctrl+z를 입력하면 프로그램을 suspend, ctrl+c를 입력하면 프로그램 종료시키도록 구현한다. 

./myshell로 실행시킬 수 있다.