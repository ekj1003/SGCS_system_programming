/* $begin shellmain */
#include "csapp.h"
#include <errno.h>
#define MAXARGS 128

/* Function prototypes */
void eval(char *cmdline);
int parseline(char *buf, char **argv);
int builtin_command(char **argv);
void execPipe(char* cmdline);
void sigset_setting(sigset_t *mask_a, sigset_t *mask_b, sigset_t *mask_f);
void handle_sigint(int sig);
void handle_sigtstp(int sig);
void handle_sigchld(int sig);